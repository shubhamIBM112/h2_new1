package com.demo.vo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"serviceDisplayName",
"resourceFamily",
"resourceGroup",
"usageType"
})
public class Category {

@JsonProperty("serviceDisplayName")
private String serviceDisplayName;
@JsonProperty("resourceFamily")
private String resourceFamily;
@JsonProperty("resourceGroup")
private String resourceGroup;
@JsonProperty("usageType")
private String usageType;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("serviceDisplayName")
public String getServiceDisplayName() {
return serviceDisplayName;
}

@JsonProperty("serviceDisplayName")
public void setServiceDisplayName(String serviceDisplayName) {
this.serviceDisplayName = serviceDisplayName;
}

@JsonProperty("resourceFamily")
public String getResourceFamily() {
return resourceFamily;
}

@JsonProperty("resourceFamily")
public void setResourceFamily(String resourceFamily) {
this.resourceFamily = resourceFamily;
}

@JsonProperty("resourceGroup")
public String getResourceGroup() {
return resourceGroup;
}

@JsonProperty("resourceGroup")
public void setResourceGroup(String resourceGroup) {
this.resourceGroup = resourceGroup;
}

@JsonProperty("usageType")
public String getUsageType() {
return usageType;
}

@JsonProperty("usageType")
public void setUsageType(String usageType) {
this.usageType = usageType;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
